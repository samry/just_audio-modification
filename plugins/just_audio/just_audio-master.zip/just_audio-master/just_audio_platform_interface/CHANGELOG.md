## 1.1.0

- Player is now disposed via JustAudioPlatform.disposePlayer().
- AudioPlayerPlatform constructor takes id parameter.

## 1.0.0

- Initial version.
