---
name: Documentation request
about: Suggest an improvement to the documentation
title: ''
labels: 1 backlog, documentation
assignees: ryanheise

---

<!--

        PLEASE READ CAREFULLY!





        FOR YOUR DOCUMENTATION REQUEST TO BE PROCESSED, YOU WILL NEED
        TO FILL IN ALL SECTIONS BELOW. DON'T DELETE THE HEADINGS.


        THANK YOU :-D


-->

**To which pages does your suggestion apply?**

- Direct URL 1
- Direct URL 2
- ...

**Quote the sentences(s) from the documentation to be improved (if any)**

> Insert here. (Skip if you are proposing an entirely new section.)

**Describe your suggestion**

...
