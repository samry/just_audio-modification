# just_audio_web

The web implementation of [`just_audio`][1].

[1]: ../just_audio
