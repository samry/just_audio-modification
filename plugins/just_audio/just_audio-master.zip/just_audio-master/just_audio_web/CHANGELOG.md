## 0.1.0

* Update to use platform interface 1.1.0.

## 0.0.1

* Migrated to the federated plugin model.
